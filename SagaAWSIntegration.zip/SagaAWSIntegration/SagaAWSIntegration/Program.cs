using Amazon.Runtime;
using Amazon.StepFunctions;
using Amazon.SQS;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// AWS configuration from appsettings.json
var awsOptions = builder.Configuration.GetSection("AWS").Get<AWSOptions>();

// Add AWS Step Functions and SQS clients
builder.Services.AddSingleton<IAmazonStepFunctions>(sp =>
{
    var credentials = new BasicAWSCredentials(awsOptions.AccessKey, awsOptions.SecretKey);
    var config = new AmazonStepFunctionsConfig
    {
        RegionEndpoint = Amazon.RegionEndpoint.GetBySystemName(awsOptions.Region)
    };
    return new AmazonStepFunctionsClient(credentials, config);
});

builder.Services.AddSingleton<IAmazonSQS>(sp =>
{
    var credentials = new BasicAWSCredentials(awsOptions.AccessKey, awsOptions.SecretKey);
    var config = new AmazonSQSConfig
    {
        RegionEndpoint = Amazon.RegionEndpoint.GetBySystemName(awsOptions.Region)
    };
    return new AmazonSQSClient(credentials, config);
});

// Add services and controllers
builder.Services.AddControllers();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();

public class AWSOptions
{
    public string AccessKey { get; set; }
    public string SecretKey { get; set; }
    public string Region { get; set; }
    public string StateMachineArn { get; set; }
}
