using Amazon.StepFunctions;
using Amazon.StepFunctions.Model;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class OrderController : ControllerBase
{
    private readonly IAmazonStepFunctions _stepFunctions;
    private readonly string _stateMachineArn;

    public OrderController(IAmazonStepFunctions stepFunctions, IConfiguration configuration)
    {
        _stepFunctions = stepFunctions;
        _stateMachineArn = configuration["AWS:StateMachineArn"];
    }

    [HttpPost("create")]
    public async Task<IActionResult> CreateOrder([FromBody] OrderRequest order)
    {
        var input = System.Text.Json.JsonSerializer.Serialize(order);

        var request = new StartExecutionRequest
        {
            StateMachineArn = _stateMachineArn,
            Input = input
        };

        try
        {
            var response = await _stepFunctions.StartExecutionAsync(request);
            return Ok(new { ExecutionArn = response.ExecutionArn, Status = "Started" });
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Error starting Step Functions execution: {ex.Message}");
        }
    }
}

public class OrderRequest
{
    public int OrderId { get; set; }
    public string Product { get; set; }
    public decimal Amount { get; set; }
}
