﻿using Amazon.SQS;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class PaymentController : ControllerBase
{
    private readonly IAmazonSQS _sqsClient;

    public PaymentController(IAmazonSQS sqsClient)
    {
        _sqsClient = sqsClient;
    }

    [HttpPost("process")]
    public async Task<IActionResult> ProcessPayment([FromBody] PaymentRequest payment)
    {
        // Logic to process payment goes here
        // Simulate payment success
        var response = new { Status = "PaymentProcessed", PaymentId = Guid.NewGuid() };
        return Ok(response);
    }
}

public class PaymentRequest
{
    public int OrderId { get; set; }
    public decimal Amount { get; set; }
    public string PaymentMethod { get; set; }
}
