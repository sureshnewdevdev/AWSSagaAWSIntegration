﻿using Amazon.SQS;
using Microsoft.AspNetCore.Mvc;

[Route("api/[controller]")]
[ApiController]
public class NotificationController : ControllerBase
{
    private readonly IAmazonSQS _sqsClient;

    public NotificationController(IAmazonSQS sqsClient)
    {
        _sqsClient = sqsClient;
    }

    [HttpPost("send")]
    public IActionResult SendNotification([FromBody] NotificationRequest notification)
    {
        // Logic to send notification goes here
        // Simulate notification success
        return Ok(new { Status = "NotificationSent", NotificationId = Guid.NewGuid() });
    }
}

public class NotificationRequest
{
    public int OrderId { get; set; }
    public string Email { get; set; }
    public string Message { get; set; }
}
